--
-- PostgreSQL database dump
--

\restrict PCVuZ9FvI8K6tjh9Vkzuj03lEOO5EZoVaFtewAsABZG4UEnF0H4ifLGWzpgR35e

-- Dumped from database version 18.6 (c021049)
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AttendanceStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AttendanceStatus" AS ENUM (
    'present',
    'absent'
);


--
-- Name: HolidayType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."HolidayType" AS ENUM (
    'friday',
    'eid',
    'puja',
    'national',
    'semester_break',
    'other'
);


--
-- Name: InviteRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InviteRole" AS ENUM (
    'departmentAdmin',
    'teacher'
);


--
-- Name: MarkedBy; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MarkedBy" AS ENUM (
    'manual',
    'search',
    'self'
);


--
-- Name: PublicRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PublicRole" AS ENUM (
    'student',
    'teacher'
);


--
-- Name: Role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Role" AS ENUM (
    'admin',
    'departmentAdmin',
    'teacher',
    'student'
);


--
-- Name: Section; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Section" AS ENUM (
    'A',
    'B',
    'C',
    'D'
);


--
-- Name: SessionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SessionStatus" AS ENUM (
    'active',
    'ended'
);


--
-- Name: Shift; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Shift" AS ENUM (
    '1st',
    '2nd'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: admin_invites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_invites (
    id text NOT NULL,
    role public."InviteRole" NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    department_id text,
    department_code text,
    shift public."Shift",
    semester integer,
    section public."Section",
    subject_name text,
    subject_code text,
    invited_by text,
    code text NOT NULL,
    code_expire timestamp(3) without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL,
    used_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: attendances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendances (
    id text NOT NULL,
    session_id text NOT NULL,
    student_id text NOT NULL,
    subject_id text NOT NULL,
    department_id text NOT NULL,
    semester integer NOT NULL,
    section text NOT NULL,
    class_name text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status public."AttendanceStatus" DEFAULT 'present'::public."AttendanceStatus" NOT NULL,
    scanned_at timestamp(3) without time zone,
    marked_by public."MarkedBy" DEFAULT 'manual'::public."MarkedBy" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    technology_code text DEFAULT ''::text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: feedbacks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedbacks (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    message text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: holidays; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.holidays (
    id text NOT NULL,
    title text NOT NULL,
    start_date timestamp(3) without time zone NOT NULL,
    end_date timestamp(3) without time zone NOT NULL,
    type public."HolidayType" DEFAULT 'other'::public."HolidayType" NOT NULL,
    recurring boolean DEFAULT false NOT NULL,
    description text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: ignored_misses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ignored_misses (
    id text NOT NULL,
    subject_id text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    ignored_by text NOT NULL,
    reason text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: pending_registrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pending_registrations (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    role public."PublicRole" NOT NULL,
    shift public."Shift",
    student_id_text text,
    department_id text,
    semester integer,
    section text,
    shadow_student_id text,
    mobile text,
    otp text NOT NULL,
    otp_expire timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    teacher_id text NOT NULL,
    department_id text NOT NULL,
    subject_id text NOT NULL,
    semester integer NOT NULL,
    section text NOT NULL,
    shift public."Shift",
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    start_time timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    end_time timestamp(3) without time zone,
    status public."SessionStatus" DEFAULT 'active'::public."SessionStatus" NOT NULL,
    total_students integer DEFAULT 0 NOT NULL,
    present_count integer DEFAULT 0 NOT NULL,
    is_substitute boolean DEFAULT false NOT NULL,
    substitute_by text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id text NOT NULL,
    key text DEFAULT 'global'::text NOT NULL,
    attendance_threshold integer DEFAULT 70 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: student_pre_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_pre_approvals (
    id text NOT NULL,
    roll text NOT NULL,
    email text NOT NULL,
    department_id text NOT NULL,
    shift public."Shift" NOT NULL,
    semester integer NOT NULL,
    added_by text NOT NULL,
    code text NOT NULL,
    code_expire timestamp(3) without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL,
    used_at timestamp(3) without time zone,
    used_by_user_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: subjects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subjects (
    id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    department_id text NOT NULL,
    semester integer NOT NULL,
    section public."Section" NOT NULL,
    shift public."Shift" NOT NULL,
    teacher_id text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text,
    email text NOT NULL,
    password text,
    role public."Role" NOT NULL,
    shift public."Shift",
    department_id text,
    department_code text,
    semesters integer[],
    semester integer,
    section public."Section",
    subject_id text,
    student_id text,
    mobile text,
    created_by text,
    is_active boolean DEFAULT true NOT NULL,
    is_verified boolean DEFAULT false NOT NULL,
    registered boolean DEFAULT true NOT NULL,
    reg_code text,
    reg_code_expire timestamp(3) without time zone,
    verification_otp text,
    verification_expire timestamp(3) without time zone,
    reset_password_otp text,
    reset_password_expire timestamp(3) without time zone,
    login_otp text,
    login_otp_expire timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: admin_invites admin_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_invites
    ADD CONSTRAINT admin_invites_pkey PRIMARY KEY (id);


--
-- Name: attendances attendances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: feedbacks feedbacks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedbacks
    ADD CONSTRAINT feedbacks_pkey PRIMARY KEY (id);


--
-- Name: holidays holidays_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.holidays
    ADD CONSTRAINT holidays_pkey PRIMARY KEY (id);


--
-- Name: ignored_misses ignored_misses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ignored_misses
    ADD CONSTRAINT ignored_misses_pkey PRIMARY KEY (id);


--
-- Name: pending_registrations pending_registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_registrations
    ADD CONSTRAINT pending_registrations_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: student_pre_approvals student_pre_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_pre_approvals
    ADD CONSTRAINT student_pre_approvals_pkey PRIMARY KEY (id);


--
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: admin_invites_email_role_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_invites_email_role_idx ON public.admin_invites USING btree (email, role);


--
-- Name: attendances_session_id_student_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX attendances_session_id_student_id_key ON public.attendances USING btree (session_id, student_id);


--
-- Name: attendances_student_id_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attendances_student_id_date_idx ON public.attendances USING btree (student_id, date DESC);


--
-- Name: attendances_subject_id_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX attendances_subject_id_date_idx ON public.attendances USING btree (subject_id, date DESC);


--
-- Name: departments_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX departments_code_key ON public.departments USING btree (code);


--
-- Name: holidays_start_date_end_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX holidays_start_date_end_date_idx ON public.holidays USING btree (start_date, end_date);


--
-- Name: ignored_misses_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ignored_misses_date_idx ON public.ignored_misses USING btree (date);


--
-- Name: ignored_misses_subject_id_date_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ignored_misses_subject_id_date_key ON public.ignored_misses USING btree (subject_id, date);


--
-- Name: sessions_status_department_id_semester_section_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_status_department_id_semester_section_idx ON public.sessions USING btree (status, department_id, semester, section);


--
-- Name: sessions_subject_id_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_subject_id_date_idx ON public.sessions USING btree (subject_id, date);


--
-- Name: sessions_teacher_id_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_teacher_id_date_idx ON public.sessions USING btree (teacher_id, date DESC);


--
-- Name: settings_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX settings_key_key ON public.settings USING btree (key);


--
-- Name: student_pre_approvals_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX student_pre_approvals_email_key ON public.student_pre_approvals USING btree (email);


--
-- Name: student_pre_approvals_roll_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX student_pre_approvals_roll_key ON public.student_pre_approvals USING btree (roll);


--
-- Name: subjects_is_active_department_id_shift_semester_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subjects_is_active_department_id_shift_semester_idx ON public.subjects USING btree (is_active, department_id, shift, semester);


--
-- Name: subjects_teacher_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subjects_teacher_id_idx ON public.subjects USING btree (teacher_id);


--
-- Name: users_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_created_at_idx ON public.users USING btree (created_at DESC);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_role_department_id_shift_semester_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_role_department_id_shift_semester_idx ON public.users USING btree (role, department_id, shift, semester);


--
-- Name: users_role_department_id_shift_semester_section_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_role_department_id_shift_semester_section_idx ON public.users USING btree (role, department_id, shift, semester, section);


--
-- Name: users_student_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_student_id_key ON public.users USING btree (student_id);


--
-- Name: admin_invites admin_invites_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_invites
    ADD CONSTRAINT admin_invites_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: admin_invites admin_invites_invited_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_invites
    ADD CONSTRAINT admin_invites_invited_by_fkey FOREIGN KEY (invited_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: attendances attendances_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: attendances attendances_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: attendances attendances_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: attendances attendances_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendances
    ADD CONSTRAINT attendances_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ignored_misses ignored_misses_ignored_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ignored_misses
    ADD CONSTRAINT ignored_misses_ignored_by_fkey FOREIGN KEY (ignored_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ignored_misses ignored_misses_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ignored_misses
    ADD CONSTRAINT ignored_misses_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pending_registrations pending_registrations_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_registrations
    ADD CONSTRAINT pending_registrations_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: pending_registrations pending_registrations_shadow_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pending_registrations
    ADD CONSTRAINT pending_registrations_shadow_student_id_fkey FOREIGN KEY (shadow_student_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sessions sessions_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sessions sessions_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sessions sessions_substitute_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_substitute_by_fkey FOREIGN KEY (substitute_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sessions sessions_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: student_pre_approvals student_pre_approvals_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_pre_approvals
    ADD CONSTRAINT student_pre_approvals_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: student_pre_approvals student_pre_approvals_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_pre_approvals
    ADD CONSTRAINT student_pre_approvals_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: student_pre_approvals student_pre_approvals_used_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_pre_approvals
    ADD CONSTRAINT student_pre_approvals_used_by_user_id_fkey FOREIGN KEY (used_by_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: subjects subjects_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subjects subjects_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_subject_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_subject_id_fkey FOREIGN KEY (subject_id) REFERENCES public.subjects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict PCVuZ9FvI8K6tjh9Vkzuj03lEOO5EZoVaFtewAsABZG4UEnF0H4ifLGWzpgR35e

